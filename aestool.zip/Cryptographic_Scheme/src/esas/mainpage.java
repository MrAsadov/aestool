package esas;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class mainpage extends JFrame {

	private JPanel contentPane;
	private JTextField txtinput;
	private JTextField EncryptedText;
	private JTextField DecryptedText;
	SecretKeySpec secretKey ;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainpage frame = new mainpage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public mainpage() {
		setTitle("Aes Encryption tool");
		setIconImage(Toolkit.getDefaultToolkit().getImage(mainpage.class.getResource("/icons/icon.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 601, 514);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(Color.ORANGE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon(mainpage.class.getResource("/icons/icon.png")));
		lblNewLabel.setBounds(227, 0, 131, 120);
		contentPane.add(lblNewLabel);
		
		txtinput = new JTextField();
		txtinput.setFont(new Font("Tahoma", Font.BOLD, 12));
		txtinput.setHorizontalAlignment(SwingConstants.CENTER);
		txtinput.setColumns(10);
		txtinput.setBounds(191, 162, 202, 43);
		contentPane.add(txtinput);
		
		JButton btnNewButton = new JButton("Encrypt");
		btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			try {
				String inputText = txtinput.getText();
				byte[] key = "ThisIsASecretKey".getBytes(StandardCharsets.UTF_8);
				secretKey = new SecretKeySpec(key, "AES");
				Cipher encryptCipher = Cipher.getInstance("AES");
				encryptCipher.init(Cipher.ENCRYPT_MODE, secretKey);
				byte[] encrypted = encryptCipher.doFinal(inputText.getBytes(StandardCharsets.UTF_8));
				String encryptedText = Base64.getEncoder().encodeToString(encrypted);
				EncryptedText.setText(encryptedText);
				
			}catch(Exception es) {
				
			}
			}
		});
		btnNewButton.setBounds(248, 216, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnDecrypt = new JButton("Decrypt");
		btnDecrypt.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnDecrypt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				try {
					Cipher decryptCipher = Cipher.getInstance("AES");
                    decryptCipher.init(Cipher.DECRYPT_MODE, secretKey);
                    byte[] decrypted = decryptCipher.doFinal(Base64.getDecoder().decode(EncryptedText.getText()));
                    String decryptedText = new String(decrypted, StandardCharsets.UTF_8);
                    DecryptedText.setText(decryptedText);
					
				}catch(Exception es) {
					
				}
				
				
			}
		});
		btnDecrypt.setBounds(248, 340, 89, 23);
		contentPane.add(btnDecrypt);
		
		EncryptedText = new JTextField();
		EncryptedText.setFont(new Font("Tahoma", Font.BOLD, 12));
		EncryptedText.setHorizontalAlignment(SwingConstants.CENTER);
		EncryptedText.setColumns(10);
		EncryptedText.setBounds(38, 286, 508, 43);
		contentPane.add(EncryptedText);
		
		DecryptedText = new JTextField();
		DecryptedText.setFont(new Font("Tahoma", Font.BOLD, 12));
		DecryptedText.setHorizontalAlignment(SwingConstants.CENTER);
		DecryptedText.setColumns(10);
		DecryptedText.setBounds(191, 406, 202, 43);
		contentPane.add(DecryptedText);
		
		lblNewLabel_1 = new JLabel("Text for encrypt");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(198, 129, 189, 32);
		contentPane.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("Encripted Text");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_2.setBounds(198, 250, 189, 32);
		contentPane.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("Decrypt Text");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_3.setBounds(198, 374, 189, 32);
		contentPane.add(lblNewLabel_3);
	}
}
